package sptech.school;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConfiguracaoBanco {
    // Lê de variáveis de ambiente (bom para Docker/EC2); se não existirem, usa o padrão local.
    private static final String HOST = env("DB_HOST", "testeBD");
    private static final String PORT = env("DB_PORT", "3306");
    private static final String DATABASE = env("DB_NAME", "db_peakstack");
    private static final String USER = env("DB_USER", "root");
    private static final String PASSWORD = env("DB_PASSWORD", "");

    private static final String URL =
            "jdbc:mysql://" + HOST + ":" + PORT + "/" + DATABASE + "?useSSL=false&allowPublicKeyRetrieval=true";

    private static String env(String chave, String padrao) {
        String valor = System.getenv(chave);
        return (valor == null || valor.isBlank()) ? padrao : valor;
    }

    /** Texto curto para exibir no console (sem senha). */
    public static String resumo() {
        return HOST + ":" + PORT + "/" + DATABASE;
    }

    public static Connection getConexao() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
