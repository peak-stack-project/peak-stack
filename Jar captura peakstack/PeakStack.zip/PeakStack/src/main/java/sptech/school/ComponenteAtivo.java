package sptech.school;

/** Uma linha da config_maq ativa da máquina + o que precisa saber para coletar. */
public record ComponenteAtivo(
        int configMaqId,
        int componenteId,
        int empresaId,
        String nome,
        String tipo,
        String unidadeMedida,
        String codigo) {
}
