package sptech.school;

import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;

public class Main {
    public static void main(String[] args) {
        // garante UTF-8 na saída (acentos)
        System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out), true, StandardCharsets.UTF_8));

        long intervaloSegundos = lerIntervaloSegundos();
        Captura captura = new Captura(intervaloSegundos);

        while (true) {
            try {
                captura.executarCaptura();
                Thread.sleep(intervaloSegundos * 1000);
            } catch (InterruptedException e) {
                Saida.erro("Loop interrompido: " + e.getMessage());
                break;
            } catch (Exception e) {
                Saida.erro("Erro na captura: " + e.getMessage());
            }
        }
    }

    /**
     * Lê o intervalo (em segundos) da variável de ambiente INTERVALO_SEGUNDOS.
     * Se não existir ou for inválida, usa 5 segundos.
     */
    private static long lerIntervaloSegundos() {
        long padrao = 5;
        String valor = System.getenv("INTERVALO_SEGUNDOS");
        if (valor == null || valor.isBlank()) {
            return padrao;
        }
        try {
            long segundos = Long.parseLong(valor.trim());
            if (segundos < 1) {
                Saida.aviso("INTERVALO_SEGUNDOS deve ser >= 1. Usando " + padrao + " s.");
                return padrao;
            }
            return segundos;
        } catch (NumberFormatException e) {
            Saida.aviso("INTERVALO_SEGUNDOS inválido ('" + valor + "'). Usando " + padrao + " s.");
            return padrao;
        }
    }
}
