package sptech.school;

import com.github.britooo.looca.api.core.Looca;
import com.github.britooo.looca.api.group.rede.RedeInterface;

import java.util.ArrayList;
import java.util.List;


public class Coletor {
    private final Looca looca = new Looca();

    // estado para calcular a velocidade entre duas leituras
    private long ultimoBytesRecebidos = -1;
    private long ultimoTempoNano = 0;

    public Double coletar(String tipo, String unidade, String codigo) {
        if (!"REDE".equalsIgnoreCase(tipo.trim())) return null;

        String un = unidade.trim().toUpperCase();
        if (un.equals("MB")) {
            if (codigo != null && codigo.toLowerCase().contains("bytes_sent")) {
                return bytesEnviadosMB();
            }
            return bytesRecebidosMB();
        }
        if (un.equals("MBPS")) {
            return velocidadeDownloadMbps();
        }
        return null;
    }

    // Looca guarda um "retrato" das interfaces ao ser criado; por isso uma instância nova a cada
    // leitura, senão os bytes ficam sempre iguais (e a velocidade sempre 0).
    private List<RedeInterface> interfacesComIp() {
        return new Looca().getRede().getGrupoDeInterfaces().getInterfaces().stream()
                .filter(i -> i.getEnderecoIpv4() != null && !i.getEnderecoIpv4().isEmpty())
                .toList();
    }

    private long totalBytesRecebidos() {
        return interfacesComIp().stream().mapToLong(RedeInterface::getBytesRecebidos).sum();
    }

    private long totalBytesEnviados() {
        return interfacesComIp().stream().mapToLong(RedeInterface::getBytesEnviados).sum();
    }

    private Double bytesRecebidosMB() {
        return totalBytesRecebidos() / (1024.0 * 1024.0);
    }

    private Double bytesEnviadosMB() {
        return totalBytesEnviados() / (1024.0 * 1024.0);
    }

    private Double velocidadeDownloadMbps() {
        long bytes = totalBytesRecebidos();
        long agora = System.nanoTime();

        if (ultimoBytesRecebidos < 0) {
            ultimoBytesRecebidos = bytes;
            ultimoTempoNano = agora;
            return null;
        }

        double segundos = (agora - ultimoTempoNano) / 1_000_000_000.0;
        long delta = Math.max(0, bytes - ultimoBytesRecebidos);
        ultimoBytesRecebidos = bytes;
        ultimoTempoNano = agora;

        if (segundos <= 0) return null;
        return (delta * 8.0 / 1_000_000.0) / segundos;
    }

    /**
     * MACs (12 caracteres, maiúsculo, sem separador) de todas as placas com IPv4.
     * Placas reais vêm primeiro; virtuais (VirtualBox, VMware, Hyper-V, etc.) vão para o fim.
     */
    public List<String> macsCandidatos() {
        List<RedeInterface> comIp = looca.getRede().getGrupoDeInterfaces().getInterfaces().stream()
                .filter(i -> i.getEnderecoIpv4() != null && !i.getEnderecoIpv4().isEmpty())
                .filter(i -> i.getEnderecoMac() != null && !i.getEnderecoMac().isBlank())
                .toList();

        List<String> reais = new ArrayList<>();
        List<String> virtuais = new ArrayList<>();
        for (RedeInterface i : comIp) {
            String mac = i.getEnderecoMac().replace(":", "").replace("-", "").toUpperCase();
            String nome = ((i.getNomeExibicao() == null ? "" : i.getNomeExibicao()) + " "
                    + (i.getNome() == null ? "" : i.getNome())).toLowerCase();
            boolean virtual = nome.contains("virtual") || nome.contains("vmware")
                    || nome.contains("hyper-v") || nome.contains("vethernet")
                    || nome.contains("loopback") || nome.contains("vbox")
                    || mac.startsWith("0A0027");
            List<String> destino = virtual ? virtuais : reais;
            if (!destino.contains(mac)) destino.add(mac);
        }
        reais.addAll(virtuais);
        return reais;
    }
}
