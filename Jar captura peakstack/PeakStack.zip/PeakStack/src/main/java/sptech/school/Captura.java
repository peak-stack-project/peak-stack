package sptech.school;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Captura {
    // Select de configuracao (maquina pelo MAC + config_maq 'Ativo'), restrito a componentes de Rede
    private static final String SQL_CONFIG = """
            SELECT cm.id AS config_maq_id, cm.fk_componentes, m.fk_empresa,
                   c.nome, cc.tipo, cc.unidade_medida, cc.codigo
            FROM maquina m
            JOIN config_maq cm        ON cm.fk_maquina = m.id
            JOIN componentes c        ON c.id = cm.fk_componentes
            JOIN configuracao_comp cc ON cc.id = c.fk_configuracao_comp
            WHERE UPPER(m.mac_address) = ?
              AND cm.status_config = 'Ativo'
              AND UPPER(cc.tipo) = 'REDE'
            ORDER BY cm.id
            """;

    private static final String SQL_NOME_MAQUINA =
            "SELECT nome FROM maquina WHERE UPPER(mac_address) = ? LIMIT 1";

    private static final String SQL_LEITURA =
            "INSERT INTO leitura (valor, fk_config_maq) VALUES (?, ?)";

    private static final String SQL_LIMITE = """
            SELECT nivel, valor_min, valor_max
            FROM limites
            WHERE fk_componentes = ? AND fk_empresa = ?
              AND ? BETWEEN valor_min AND valor_max
            ORDER BY nivel DESC
            LIMIT 1
            """;

    private static final String SQL_DISCRETIZADA =
            "INSERT INTO discretizada (fk_leitura, situacao, descricao, consciente) VALUES (?, ?, ?, 0)";

    private final Coletor coletor = new Coletor();
    private final long intervaloSegundos;
    private final List<String> macsCandidatos;
    private String mac;
    private List<ComponenteAtivo> componentes = new ArrayList<>();
    private boolean cabecalhoExibido = false;

    public Captura(long intervaloSegundos) {
        this.intervaloSegundos = intervaloSegundos;
        this.macsCandidatos = coletor.macsCandidatos();
        if (macsCandidatos.isEmpty()) {
            throw new IllegalStateException("Nao foi possivel obter o MAC address da maquina.");
        }
        Saida.info("MACs encontrados na maquina: " + macsCandidatos);
    }

    public void carregarConfiguracao(Connection conn) throws SQLException {
        for (String candidato : macsCandidatos) {
            List<ComponenteAtivo> lista = buscarConfig(conn, candidato);
            if (!lista.isEmpty()) {
                this.mac = candidato;
                this.componentes = lista;
                return;
            }
        }
        this.componentes = new ArrayList<>();
    }

    private List<ComponenteAtivo> buscarConfig(Connection conn, String macBusca) throws SQLException {
        List<ComponenteAtivo> lista = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(SQL_CONFIG)) {
            ps.setString(1, macBusca);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new ComponenteAtivo(
                            rs.getInt("config_maq_id"),
                            rs.getInt("fk_componentes"),
                            rs.getInt("fk_empresa"),
                            rs.getString("nome"),
                            rs.getString("tipo"),
                            rs.getString("unidade_medida"),
                            rs.getString("codigo")));
                }
            }
        }
        return lista;
    }

    public void executarCaptura() {
        try (Connection conn = ConfiguracaoBanco.getConexao()) {
            carregarConfiguracao(conn);

            if (componentes.isEmpty()) {
                Saida.aviso("Nenhuma configuracao ativa para os MACs " + macsCandidatos
                        + " (maquina cadastrada em 'maquina' e com config_maq 'Ativo'?)");
                return;
            }

            if (!cabecalhoExibido) {
                Saida.cabecalho(buscarNomeMaquina(conn), mac, ConfiguracaoBanco.resumo(), intervaloSegundos);
                cabecalhoExibido = true;
            }

            for (ComponenteAtivo comp : componentes) {
                try {
                    Double valor = coletor.coletar(comp.tipo(), comp.unidadeMedida(), comp.codigo());
                    if (valor == null) {
                        if ("Mbps".equalsIgnoreCase(comp.unidadeMedida())) {
                            Saida.aviso("Velocidade: aguardando a 2a leitura para calcular");
                        } else {
                            Saida.aviso("Sem coleta para " + comp.tipo() + " (" + comp.unidadeMedida() + ") - nao suportado");
                        }
                        continue;
                    }
                    BigDecimal v = BigDecimal.valueOf(valor).setScale(2, RoundingMode.HALF_UP);
                    int leituraId = inserirLeitura(conn, comp, v);
                    String nivel = discretizar(conn, comp, leituraId, v);
                    Saida.leitura(rotulo(comp), v.toPlainString(), comp.unidadeMedida(), nivel);
                } catch (SQLException e) {
                    Saida.erro("Erro ao gravar " + rotulo(comp).toLowerCase()
                            + " (config_maq " + comp.configMaqId() + "): " + e.getMessage());
                }
            }
        } catch (SQLException e) {
            Saida.erro("Erro de banco: " + e.getMessage());
        }
    }

    private String buscarNomeMaquina(Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(SQL_NOME_MAQUINA)) {
            ps.setString(1, mac);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getString("nome");
            }
        } catch (SQLException e) {
            // só para o cabecalho; segue sem o nome
        }
        return "(sem nome)";
    }

    private int inserirLeitura(Connection conn, ComponenteAtivo comp, BigDecimal valor) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(SQL_LEITURA, Statement.RETURN_GENERATED_KEYS)) {
            ps.setBigDecimal(1, valor);
            ps.setInt(2, comp.configMaqId());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return keys.getInt(1);
            }
        }
    }

    private String discretizar(Connection conn, ComponenteAtivo comp, int leituraId, BigDecimal valor) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(SQL_LIMITE)) {
            ps.setInt(1, comp.componenteId());
            ps.setInt(2, comp.empresaId());
            ps.setBigDecimal(3, valor);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                int nivel = rs.getInt("nivel");
                String situacao = "Nivel " + nivel;
                String descricao = "Faixa " + rs.getBigDecimal("valor_min") + " a " + rs.getBigDecimal("valor_max");
                try (PreparedStatement ins = conn.prepareStatement(SQL_DISCRETIZADA)) {
                    ins.setInt(1, leituraId);
                    ins.setString(2, situacao);
                    ins.setString(3, descricao);
                    ins.executeUpdate();
                }
                return situacao;
            }
        }
    }

    private String rotulo(ComponenteAtivo comp) {
        if ("Mbps".equalsIgnoreCase(comp.unidadeMedida())) return "Velocidade";
        if (comp.codigo() != null && comp.codigo().contains("bytes_sent")) return "Upload";
        return "Download";
    }
}