package sptech.school;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/** Formatação da saída do console: apenas texto, alinhado em colunas. */
public class Saida {
    private static final DateTimeFormatter HORA = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final String LINHA = "=".repeat(60);

    private static String hora() {
        return "[" + LocalTime.now().format(HORA) + "]";
    }

    public static void cabecalho(String maquina, String mac, String banco, long intervaloSegundos) {
        System.out.println();
        System.out.println(LINHA);
        System.out.println("PEAKSTACK - Captura de rede");
        System.out.println(LINHA);
        System.out.println(String.format("%-10s: %s", "Maquina", maquina + " (MAC " + mac + ")"));
        System.out.println(String.format("%-10s: %s", "Banco", banco));
        System.out.println(String.format("%-10s: %s", "Intervalo", intervaloSegundos + " s"));
        System.out.println(LINHA);
        System.out.println(String.format("%-10s %-6s %-12s %12s  %s", "HORA", "STATUS", "METRICA", "VALOR", "NIVEL"));
        System.out.println("-".repeat(60));
    }

    /** Exemplo: [23:38:01] OK     Download           267.75 MB  Nivel 1 */
    public static void leitura(String metrica, String valor, String unidade, String nivel) {
        System.out.println(String.format("%-10s %-6s %-12s %12s  %s",
                hora(), "OK", metrica, valor + " " + unidade, nivel == null ? "-" : nivel));
    }

    public static void info(String mensagem) {
        System.out.println(mensagem);
    }

    public static void aviso(String mensagem) {
        System.out.println(String.format("%-10s %-6s %s", hora(), "AVISO", mensagem));
    }

    public static void erro(String mensagem) {
        System.out.println(String.format("%-10s %-6s %s", hora(), "ERRO", mensagem));
    }
}
