import java.util.ArrayList;
import java.util.List;

public class Empresa {
    String nomeEmpresa;
    String nomeSite;
    String CNPJ;
    String emailADM;
    String senhaADM;
    String codigoIdentificador;

    List<Funcionario> lista_funcionario = new ArrayList<>();

    Empresa(String nome, String site, String cnpj, String email, String senha, String codigo){
        nomeEmpresa = nome;
        nomeSite = site;
        CNPJ = cnpj;
        emailADM = email;
        senhaADM = senha;
        codigoIdentificador = codigo;
    }
}
