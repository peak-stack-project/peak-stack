import java.math.BigInteger;

public class Funcionario {
    String nomeFuncionario;
    String CPF;
    String telefoneFuncionario;
    String emailFuncionario;
    String senhaFuncionario;
    String codigoEmpresa;

    Funcionario(String nome, String cpf, String telefone, String email, String senha, String codigo){
        nomeFuncionario = nome;
        CPF = cpf;
        telefoneFuncionario = telefone;
        emailFuncionario = email;
        senhaFuncionario = senha;
        codigoEmpresa = codigo;
    }
}
