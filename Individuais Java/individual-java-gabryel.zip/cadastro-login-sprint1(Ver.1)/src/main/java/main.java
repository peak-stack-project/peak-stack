import java.sql.SQLOutput;

void main() {
    Scanner input = new Scanner(System.in);
    List<Empresa> lista_empresa = new ArrayList<>();

    boolean loop = true;
    while (loop){
        System.out.println("""
               ======== MENU ========
               [1]. Cadastro
               [2]. Login
               [3]. Sair
               ======================
               """);

        System.out.println("Informe uma das opções acima para prosseguir: ");
        int opc = input.nextInt();
        input.nextLine();

        // Cadastro
        if (opc == 1){
            System.out.println("""
               ========== MENU ==========
               [1]. Cadastro Empresa
               [2]. Voltar
               ==========================
               """);

            System.out.println("Informe uma das opções acima para prosseguir: ");
            opc = input.nextInt();
            input.nextLine();

            // Cadastro Empresa
            if (opc == 1){
                System.out.println("Informe o Nome da Empresa: ");
                String nome = input.nextLine();

                System.out.println("Informe o Site a ser Monitorado: ");
                String site = input.nextLine();

                System.out.println("Informe o CNPJ da Empresa: ");
                String cnpj = input.nextLine();

                System.out.println("Informe o Email da Empresa: ");
                String email = input.nextLine();

                System.out.println("Informe a Senha: ");
                String senha = input.nextLine();

                System.out.println("Informe o CÓDIGO Identificador da empresa: ");
                String codigo = input.nextLine();

                Empresa nova_empresa = new Empresa(nome, site, cnpj, email, senha, codigo);
                lista_empresa.add(nova_empresa);
                System.out.println();
            }
        }

        // Login
        else if (opc == 2){
            System.out.println("""
               ========== MENU ==========
               [1]. Login Empresa
               [2]. Login Funcionário
               [3]. Voltar
               ==========================
               """);

            System.out.println("Informe uma das opções acima para prosseguir: ");
            opc = input.nextInt();
            input.nextLine();

            // Login Empresa
            if (opc == 1){
                System.out.println("""
                        ================ LOGIN EMPRESA ================
                        """);
                System.out.println("Informe o seu Email Empresarial: ");
                String email = input.nextLine();

                System.out.println("Informe a sua Senha: ");
                String senha = input.nextLine();

                Empresa empresa_logada = null;
                for (int i = 0; i < lista_empresa.size(); i++) {
                    Empresa e = lista_empresa.get(i);
                    if (e.emailADM.equals(email) && e.senhaADM.equals(senha)){
                        empresa_logada = e;
                    }
                }

                if (empresa_logada != null){
                    System.out.printf("Login Realizado com Sucesso. Empresa: %s", empresa_logada.nomeEmpresa);
                    System.out.println("");

                    while (opc != 4) {
                        System.out.println("");
                        System.out.println("""
                            ================ MENU EMPRESA ================
                            [1]. Cadastrar Funcionário
                            [2]. Visualizar Lista de Funcionários
                            [3]. Retirar Funcionário
                            [4]. Sair
                            ==============================================
                            """);

                        opc = input.nextInt();
                        input.nextLine();

                        if (opc == 1){
                            System.out.println("""
                            ================ CADASTRO FUNCIONÁRIO ================
                            """);

                            System.out.println("Informe o Nome do Funcionário: ");
                            String nome = input.nextLine();

                            System.out.println("Informe o CPF do Funcionário: ");
                            String cpf = input.nextLine();

                            System.out.println("Informe o telefone do Funcionário: ");
                            String telefone = input.nextLine();

                            System.out.println("Informe o Email Institucional do Funcionário: ");
                            String emailFuncionario = input.nextLine();

                            System.out.println("Informe uma Senha Temporária: ");
                            String senhaFuncionario = input.nextLine();

                            String codigo = empresa_logada.codigoIdentificador;

                            Funcionario novo_funcionario = new Funcionario(nome, cpf, telefone, emailFuncionario, senhaFuncionario, codigo);

                            empresa_logada.lista_funcionario.add(novo_funcionario);
                            System.out.println();
                        }

                        else if (opc == 2){
                            System.out.println("""
                            ================ LISTA DE FUNCIONÁRIOS ================
                            """);

                            for (int i = 0; i < empresa_logada.lista_funcionario.size(); i++) {
                                Funcionario f = empresa_logada.lista_funcionario.get(i);

                                if (empresa_logada.lista_funcionario.isEmpty()){
                                    System.out.println("Não há nenhum funcionário cadastrado.");
                                } else{
                                    System.out.printf("Nome: %s, CPF: %s, Email: %s, Telefone: %s", f.nomeFuncionario, f.CPF, f.emailFuncionario, f.telefoneFuncionario);
                                    System.out.println("");
                                }
                            }
                        }

                        else if (opc == 3) {
                            System.out.println("""
                            ================ RETIRAR FUNCIONÁRIO ================
                            """);

                            System.out.println("Informe o numero do CPF do funcionário a ser retirado: ");
                            String cpf_escolhido = input.nextLine();

                            for (int i = 0; i < empresa_logada.lista_funcionario.size(); i++) {
                                Funcionario f = empresa_logada.lista_funcionario.get(i);

                                if (f.CPF.equals(cpf_escolhido) == true){
                                    System.out.println("Funcionário Encontrado!");
                                    System.out.printf("Nome do Funcionário: %s", f.nomeFuncionario);
                                    System.out.println("");

                                    System.out.printf("Deseja realmente retirar o funcionário %s do grupo que pode visualizar o monitorar do componente? [S / N] ", f.nomeFuncionario);
                                    String esc = input.nextLine();

                                    if (esc.equals("S")){
                                        empresa_logada.lista_funcionario.remove(i);
                                        System.out.println("Funcionário removido com sucesso!");
                                        System.out.println("");
                                    }
                                }
                            }
                        }
                    }
                }

                else{
                    System.out.println("ERRO. Verifique se o seu Email e Senha foram inseridos corretamente.");
                }
            }

            // Login Funcionario
            else if (opc == 2) {
                System.out.println("""
                    ================ LOGIN FUNCIONARIO ================
                    """);
                System.out.println("Informe o CÓDIGO Identificador da empresa: ");
                String codigo = input.nextLine();

                System.out.println("Informe o seu CPF: ");
                String cpf = input.nextLine();

                System.out.println("Informe a sua Senha: ");
                String senha = input.nextLine();

                Funcionario funcionario_logado = null;
                Empresa empresa_Funcionario = null;
                for (int i = 0; i < lista_empresa.size(); i++) {
                    Empresa e = lista_empresa.get(i);
                    if (e.codigoIdentificador.equals(codigo)){
                        empresa_Funcionario = e;

                        for (int i1 = 0; i1 < e.lista_funcionario.size(); i1++) {
                            Funcionario f = e.lista_funcionario.get(i);

                            if (f.CPF.equals(cpf) && f.senhaFuncionario.equals(senha)){
                                funcionario_logado = f;
                            }

                            else {
                                System.out.println("ERRO: Funcionário não encontrado.");
                                System.out.println("ERRO: Verifique se Código, CPF e Senha foram inseridos corretamente.");
                            }
                        }

                        if (funcionario_logado != null){
                            System.out.printf("Login Realizado com Sucesso. Seja Bem-Vindo(a) %s", funcionario_logado.nomeFuncionario);
                            System.out.println("");

                            while (opc != 3){
                                System.out.println("""
                                ================ MENU FUNCIONARIO ================
                                [1]. Visualizar Perfil do Funcionário
                                [2]. Atualizar Dados do Funcionário
                                [3]. Sair
                                ==================================================
                                """);

                                opc = input.nextInt();
                                input.nextLine();

                                if (opc == 1){
                                    System.out.println("""
                                    ================ VISUALIZAR PERFIL ================
                                    """);

                                    System.out.printf("Nome: %s, CPF: %s, Telefone: %s, Email: %s, Senha: %s, Afiliado(a) à Empresa: %s", funcionario_logado.nomeFuncionario, funcionario_logado.CPF, funcionario_logado.telefoneFuncionario, funcionario_logado.emailFuncionario, funcionario_logado.senhaFuncionario, empresa_Funcionario.nomeEmpresa);
                                    System.out.println("");
                                }

                                else if (opc == 2) {
                                    System.out.println("""
                                    ================ ATUALIZAR PERFIL ================
                                    """);

                                    System.out.println("Informe qual dos dados você deseja atualizar: ");
                                    System.out.println("""
                                            [1]. Telefone
                                            [2]. Senha
                                            [3]. Voltar
                                            """);
                                    opc = input.nextInt();
                                    input.nextLine();

                                    if (opc == 1) {
                                        System.out.println("Informe o novo numero de Telefone: ");
                                        String telefone = input.nextLine();

                                        funcionario_logado.telefoneFuncionario = telefone;
                                        System.out.println("Telefone Atualizado com sucesso!");
                                    } else if (opc == 2) {
                                        System.out.println("Informe a nova Senha: ");
                                        String senhaNova = input.nextLine();

                                        funcionario_logado.senhaFuncionario = senhaNova;
                                        System.out.println("Senha Atualizada com sucesso!");
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Sair
        else{
            System.out.println("Agradecemos o Acesso.");
            loop = false;
        }
    }
}