package school.sptech;

import java.util.Scanner;

public class IndividualMalu {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Quantas empresas você quer cadastrar: ");
            int quantidadeEmpresas = scanner.nextInt();

            String[] nomes = new String[quantidadeEmpresas];
            int[] problemas = new int[quantidadeEmpresas];

            scanner.nextLine();

            for (int i = 0; i < quantidadeEmpresas; i++) {
                System.out.println();
                System.out.print("Digite o nome da empresa " + (i + 1) + ": ");
                nomes[i] = scanner.nextLine();

                System.out.print("Quantas vezes essa empresa teve queda ou lentidão: ");
                problemas[i] = scanner.nextInt();
                scanner.nextLine();
            }

            System.out.println();
            System.out.println("RELATÓRIO");

            for (int i = 0; i < quantidadeEmpresas; i++) {
                String nivel;

                if (problemas[i] == 0) {
                    nivel = "Sem problemas registrados";
                } else if (problemas[i] <= 3) {
                    nivel = "Nível baixo";
                } else if (problemas[i] <= 7) {
                    nivel = "Nível médio";
                } else {
                    nivel = "Nível alto (atenção!)";
                }

                System.out.println();
                System.out.println("Empresa: " + nomes[i]);
                System.out.println("Quedas/lentidão: " + problemas[i]);
                System.out.println("Classificação: " + nivel);
            }

            scanner.close();
        }
}
