package school.sptech;

import java.util.Scanner;

public class JavaGrupo{

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        String nome;
        Integer anoNascimento;
        String email;
        String nomeEmpresa;
        String senha;
        String repeticaoSenha;

        do {
            System.out.print("Digite seu nome: ");
            nome = scanner.nextLine();

            if (nome.length() <= 2) {
                System.out.println("Nome inválido!");
            }

        } while (nome.length() <= 2);

        do {
            System.out.print("Digite seu ano de nascimento: ");
            anoNascimento = scanner.nextInt();

            if (2026 - anoNascimento < 18) {
                System.out.println("Você precisa ser maior de idade!");
            }

        } while (2026 - anoNascimento < 18);

        scanner.nextLine();

        do {
            System.out.print("Digite seu e-mail: ");
            email = scanner.nextLine();

            if (!email.contains("@") || !email.contains(".")) {
                System.out.println("E-mail inválido!");
            }

        } while (!email.contains("@") || !email.contains("."));

        System.out.print("Digite o nome da empresa em que trabalha: ");
        nomeEmpresa = scanner.nextLine();

        do {
            System.out.print("Digite sua senha: ");
            senha = scanner.nextLine();

            if (senha.length() < 6) {
                System.out.println("A senha deve ter pelo menos 6 caracteres!");
            }
            if (!senha.contains("@") && !senha.contains("&") && !senha.contains("#") &&
                    !senha.contains("$") && !senha.contains("!") && !senha.contains("%")) {
                System.out.println("A senha deve ter pelo menos 1 caracter especial!");
            }

        } while (senha.length() < 6 || (!senha.contains("@") && !senha.contains("&") && !senha.contains("#") &&
                !senha.contains("$") && !senha.contains("!") && !senha.contains("%")));

        do {
            System.out.print("Repita a sua senha: ");
            repeticaoSenha = scanner.nextLine();

            if (!repeticaoSenha.equals(senha)) {
                System.out.println("Senha diferente!");
            }
        } while (!repeticaoSenha.equals(senha));

        System.out.print("Quantas vezes a sua empresa teve queda ou lentidão recente: ");
        int problemas = scanner.nextInt();

        String nivel;
        if (problemas == 0) {
            nivel = "Sem problemas registrados";
        } else if (problemas <= 3) {
            nivel = "Nível baixo";
        } else if (problemas <= 7) {
            nivel = "Nível médio";
        } else {
            nivel = "Nível alto (atenção!)";
        }

        System.out.println("\n===== CADASTRO REALIZADO =====");
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + (2026 - anoNascimento));
        System.out.println("E-mail: " + email);
        System.out.println("Empresa: " + nomeEmpresa);
        System.out.println("Status de Estabilidade: " + nivel);

        scanner.close();
    }
}
