package school.sptech;

import java.util.Scanner;

public class IndividualFelipe {
    static void main() {
        Scanner scanner = new Scanner(System.in);

        String nome;
        String dataNascimento;
        String email;
        String senha;

        do {
            System.out.println("Digite o seu nome: ");
            nome = scanner.nextLine();

            if (nome.length() < 3) {
                System.out.println("Nome inválido, preencha esse campo com algum nome");
            }
        } while (nome.length() < 3);

        do {
            System.out.println("Digite a sua data de nascimento (dd/mm/aaaa): ");
            dataNascimento = scanner.nextLine();

            if (dataNascimento.length() != 10) {
                System.out.println("Data de nascimento inválida");
            }
        } while (dataNascimento.length() != 10);

        do {
            System.out.println("Informe o seu email: ");
            email = scanner.nextLine();

            if (email.length() == 0) {
                System.out.println("Email inválido");
            } else if (!email.contains("@") || !email.contains(".")) {
                System.out.println("Email inválido");
            }
        } while (email.length() == 0 || !email.contains("@") || !email.contains("."));

    
        do {
            System.out.println("Digite a sua senha: ");
            senha = scanner.nextLine();

            if (senha.length() < 8) {
                System.out.println("Senha invalida");
            } else if (!senha.contains("!") && !senha.contains("@") && !senha.contains("#")
                    && !senha.contains("$") && !senha.contains("%") && !senha.contains("&")
                    && !senha.contains("*")) {
                System.out.println("Senha invalida");
            }
        } while (senha.length() < 8
                || (!senha.contains("!") && !senha.contains("@") && !senha.contains("#")
                && !senha.contains("$") && !senha.contains("%") && !senha.contains("&")
                && !senha.contains("*")));

        System.out.println("\n---CADASTRO REALIZADO---");
        System.out.println("Nome: " + nome);
        System.out.println("Data de nascimento: " + dataNascimento);
        System.out.println("Email: " + email);
        System.out.println("Senha: " + senha);
        System.out.println("-------------------------");
    }
}
