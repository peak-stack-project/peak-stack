package school.sptech;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        String nome = "";
        String email = "";
        String senha = "";

        Integer opcao;

        do {

            System.out.println("\n========== MENU ==========");
            System.out.println("1 - Cadastrar");
            System.out.println("2 - Fazer login");
            System.out.println("3 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            if (opcao == 1) {

                System.out.print("\nDigite seu nome: ");
                nome = scanner.nextLine();

                System.out.print("Digite seu e-mail: ");
                email = scanner.nextLine();

                System.out.print("Digite sua senha: ");
                senha = scanner.nextLine();

                System.out.println("\nCadastro realizado com sucesso!");

            } else if (opcao == 2) {

                System.out.println("\n========== LOGIN ==========");

                System.out.print("Digite seu e-mail: ");
                String emailLogin = scanner.nextLine();

                System.out.print("Digite sua senha: ");
                String senhaLogin = scanner.nextLine();

                if (emailLogin.equals(email) && senhaLogin.equals(senha)) {

                    System.out.println("\nLogin realizado com sucesso!");
                    System.out.println("Bem-vindo, " + nome + "!");

                } else {

                    System.out.println("\nE-mail ou senha incorretos!");

                }

            } else if (opcao == 3) {

                System.out.println("\nPrograma encerrado!");

            } else {

                System.out.println("\nOpção inválida!");

            }

        } while (opcao != 3);

        scanner.close();
    }
}

